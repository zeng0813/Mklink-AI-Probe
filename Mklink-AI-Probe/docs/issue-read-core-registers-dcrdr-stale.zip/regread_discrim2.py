"""Discriminate (a) firmware not delivering DCSR writes vs (b) core not servicing them.

Logic:
- DCRDR (0xE000EDF8) and DCSR (0xE000EDF4) are adjacent PPB addresses served by
  the SAME cmd.write_ram AP path. If direct DCRDR write+read works in the broken
  state, the firmware's AP write to PPB is fine -> a DCSR write is almost
  certainly delivered too. If DCRDR then still does NOT refresh, the CORE is the
  one not servicing the DCSR write.
- Also dump DHCSR bits throughout to rule out 'core silently left halt/debug'.

PC (sel 15) is used as the probe register: its value is a flash address
(0x08xxxxxx), impossible to confuse with markers.
"""
import sys, time
from mklink.bridge import MKLinkSerialBridge
from mklink.debug_control import (
    DCRSR, DCRDR, DHCSR, DHCSR_S_REGRDY, halt_cpu, resume_cpu, _write_u32, _read_u32,
)

port = sys.argv[1] if len(sys.argv) > 1 else "COM5"


def wait_rd(b):
    dl = time.monotonic() + 0.5
    while True:
        if _read_u32(b, DHCSR) & DHCSR_S_REGRDY:
            return
        if time.monotonic() >= dl:
            return


def dhcsr(v):
    return (f"raw={v:#010x} C_DEBUGEN={bool(v&1)} C_HALT={bool(v&2)} "
            f"S_REGRDY={bool(v&(1<<16))} S_HALT={bool(v&(1<<17))} "
            f"S_SLEEP={bool(v&(1<<18))} S_LOCKUP={bool(v&(1<<19))} bit31={bool(v&(1<<31))}")


def is_pc(v):
    return 0x08000000 <= v <= 0x080FFFFF


b = MKLinkSerialBridge(port)
if not b.connect():
    raise SystemExit(f"connect({port}) failed")

for trial in range(3):
    print(f"\n==================== TRIAL {trial} ====================")
    resume_cpu(b); halt_cpu(b)

    print("[A fresh] DHCSR:", dhcsr(_read_u32(b, DHCSR)))
    _write_u32(b, DCRDR, 0x12345678)
    print(f"   DCRDR write 0x12345678 -> read {_read_u32(b, DCRDR):#010x} (AP-DCRDR-write works if 0x12345678)")
    _write_u32(b, DCRSR, 15)              # select PC
    wait_rd(b)
    v = _read_u32(b, DCRDR)
    print(f"   DCSR(pc) -> DCRDR {v:#010x}  refreshed={is_pc(v)}")

    print("[B hammer 20x DCSR/DCRDR ...]")
    for k in range(20):
        _write_u32(b, DCRSR, k % 8)
        wait_rd(b)
        _read_u32(b, DCRDR)
    print("   DHCSR after hammer:", dhcsr(_read_u32(b, DHCSR)))

    # C1: direct DCRDR write/read while broken
    _write_u32(b, DCRDR, 0xAABBCCDD)
    c1a = _read_u32(b, DCRDR)
    _write_u32(b, DCRDR, 0x55AA55AA)
    c1b = _read_u32(b, DCRDR)
    print(f"[C1 broken] DCRDR write 0xAABBCCDD->{c1a:#010x}  0x55AA55AA->{c1b:#010x}  "
          f"AP-DCRDR-write-works={c1a==0xAABBCCDD and c1b==0x55AA55AA}")

    # C2: does single DCSR write refresh DCRDR while broken?
    _write_u32(b, DCRDR, 0x11223344)          # marker
    m = _read_u32(b, DCRDR)
    dhb = _read_u32(b, DHCSR)
    _write_u32(b, DCRSR, 15)                   # select PC
    wait_rd(b)
    dha = _read_u32(b, DHCSR)
    c2 = _read_u32(b, DCRDR)
    print(f"[C2 broken] marker={m:#010x}; DCSR(pc)->DCRDR {c2:#010x}  "
          f"refreshed={is_pc(c2)} stuck={c2==0x11223344}")
    print(f"   DHCSR before DCSR: {dhcsr(dhb)}")
    print(f"   DHCSR after  DCSR: {dhcsr(dha)}")

    # C3: does a pause + single DCSR recover?
    time.sleep(0.1)
    _write_u32(b, DCRDR, 0x66778899)
    _write_u32(b, DCRSR, 15)
    wait_rd(b)
    c3 = _read_u32(b, DCRDR)
    print(f"[C3 after 100ms] DCSR(pc)->DCRDR {c3:#010x}  refreshed={is_pc(c3)}")

resume_cpu(b); b.close()
