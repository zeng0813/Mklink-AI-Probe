"""Boundary sweep + write-path probe for the DCRSR selector sentinel bug.

Phase 1 (read): under confirmed continuous S_HALT, read DCRSR selectors
0-18 + 20(CFBP) and record exactly which return 0xDEADBEEF. Repeated rounds;
only HALT-KEPT rounds count.

Phase 2 (write, REGWnR=1): write 0xCAFE0000|sel into sel 1/6/11, read it back,
see if the write path is also affected (writes core regs — has side effects,
kept last).
"""
import sys, time
from mklink.bridge import MKLinkSerialBridge
from mklink.debug_control import halt_cpu, resume_cpu, _read_u32, _write_u32, _wait_regrdy

port = sys.argv[1] if len(sys.argv) > 1 else "COM5"
DHCSR = 0xE000EDF0
DCRSR = 0xE000EDF4
DCRDR = 0xE000EDF8
S_HALT = 1 << 17
REGWnR = 1 << 16
SENT = 0xDEADBEEF

NAMES = {0:'r0',1:'r1',2:'r2',3:'r3',4:'r4',5:'r5',6:'r6',7:'r7',8:'r8',
         9:'r9',10:'r10',11:'r11',12:'r12',13:'sp',14:'lr',15:'pc',
         16:'xpsr',17:'msp',18:'psp',20:'CFBP'}
READ_SELS = list(range(0, 19)) + [20]

b = MKLinkSerialBridge(port)
if not b.connect():
    raise SystemExit("connect failed")


def rd(a):
    return _read_u32(b, a)


def wr(a, v):
    _write_u32(b, a, v)


def read_sel(sel):
    wr(DCRSR, sel); _wait_regrdy(b); return rd(DCRDR)


# ---- Phase 1: read boundary sweep ----
print("=== Phase 1: read sweep sel 0-18 + 20 (halt-kept only) ===")
sent_union = set()
good = 0
rep_vals = None
for rnd in range(6):
    resume_cpu(b); halt_cpu(b)
    d0 = rd(DHCSR)
    if not (d0 & S_HALT):
        continue
    vals = {}
    for sel in READ_SELS:
        try:
            vals[sel] = read_sel(sel)
        except Exception as e:
            vals[sel] = f"ERR:{type(e).__name__}"
    d1 = rd(DHCSR)
    if not ((d0 & S_HALT) and (d1 & S_HALT)):
        print(f"rnd{rnd}: HALT-LOST mid-scan, skip")
        continue
    good += 1
    sents = [s for s in READ_SELS if vals[s] == SENT]
    for s in sents:
        sent_union.add(s)
    print(f"rnd{rnd} HALT-KEPT  sentinels@{sents}")
    if rep_vals is None:
        rep_vals = vals
print(f"\nPhase1: {good} halt-kept rounds. Sentinel selector UNION = {sorted(sent_union)}")
if rep_vals:
    print("representative values from first halt-kept round:")
    for s in READ_SELS:
        v = rep_vals[s]
        nm = NAMES.get(s, '')
        vs = f"{v:#010x}" if isinstance(v, int) else v
        mark = "  <-- SENTINEL" if v == SENT else ""
        print(f"  sel{s:>2} {nm:5s} = {vs}{mark}")

# ---- Phase 2: write path (REGWnR=1) ----
print("\n=== Phase 2: write (REGWnR=1) sel 1/6/11 then readback ===")
for rnd in range(4):
    resume_cpu(b); halt_cpu(b)
    d0 = rd(DHCSR)
    if not (d0 & S_HALT):
        print(f"rnd{rnd}: not halted, skip"); continue
    out = []
    for sel in [1, 6, 11]:
        payload = 0xCAFE0000 | sel
        wr(DCRDR, payload)
        wr(DCRSR, sel | REGWnR)          # write request
        _wait_regrdy(b)
        wr(DCRSR, sel)                   # read back
        _wait_regrdy(b)
        back = rd(DCRDR)
        out.append(f"sel{sel}: w{payload:#010x}->r{back:#010x}{'OK' if back==payload else 'DIFF'}")
    d1 = rd(DHCSR)
    kept = (d0 & S_HALT) and (d1 & S_HALT)
    print(f"rnd{rnd} {'HALT-KEPT' if kept else 'HALT-LOST'}  " + "  ".join(out))

resume_cpu(b); b.close()
