"""Is DCRDR actually special, or is halt-loss general intermittent noise?

Part 1 — per-operation drop rate: for each op type, K=10 trials of fresh-halt +
20 ops, check S_HALT at end. If only DCRDR-read drops, it's special; if several
types drop similarly, it's general.
Part 2 — idle test: fresh halt, NO traffic, just sleep, then check S_HALT.
If halt holds while idle but drops under traffic -> traffic-correlated.
If halt drops even idle -> time-based (firmware timeout / periodic reset).
"""
import sys, time
from mklink.bridge import MKLinkSerialBridge
from mklink.debug_control import halt_cpu, resume_cpu, _write_u32, _read_u32

port = sys.argv[1] if len(sys.argv) > 1 else "COM5"
DHCSR = 0xE000EDF0
DCRSR = 0xE000EDF4
DCRDR = 0xE000EDF8
S_HALT = 1 << 17
S_RESET_ST = 1 << 25

OPS = {
    "read DCRDR  (0xE000EDF8)": lambda b: _read_u32(b, DCRDR),
    "read DCRSR  (0xE000EDF4)": lambda b: _read_u32(b, DCRSR),
    "read DHCSR  (0xE000EDF0)": lambda b: _read_u32(b, DHCSR),
    "read SRAM   (0x20001000)": lambda b: _read_u32(b, 0x20001000),
    "write DCRDR ":            lambda b: _write_u32(b, DCRDR, 0x12345678),
    "write DCRSR ":            lambda b: _write_u32(b, DCRSR, 0),
    "write SRAM  ":            lambda b: _write_u32(b, 0x20001000, 0xA5A55A5A),
}

b = MKLinkSerialBridge(port)
if not b.connect():
    raise SystemExit(f"connect({port}) failed")

K = 10
N = 20
print(f"=== Part 1: drop rate per op type ({K} trials x {N} ops, fresh halt each) ===")
for label, fn in OPS.items():
    drops = resets = 0
    for _ in range(K):
        resume_cpu(b); halt_cpu(b)
        _read_u32(b, DHCSR)           # clear S_RESET_ST
        for _ in range(N):
            fn(b)
        d = _read_u32(b, DHCSR)
        if not (d & S_HALT):
            drops += 1
        if d & S_RESET_ST:
            resets += 1
    print(f"  {label}: drops={drops}/{K}  resets={resets}/{K}")

print("\n=== Part 2: idle test (fresh halt, NO traffic, sleep) ===")
for secs in (0.5, 1.0, 2.0):
    drops = resets = 0
    for _ in range(6):
        resume_cpu(b); halt_cpu(b)
        _read_u32(b, DHCSR)           # clear S_RESET_ST
        time.sleep(secs)              # NO SWD traffic at all
        d = _read_u32(b, DHCSR)
        if not (d & S_HALT):
            drops += 1
        if d & S_RESET_ST:
            resets += 1
    print(f"  idle {secs}s: drops={drops}/6  resets={resets}/6")

resume_cpu(b); b.close()
