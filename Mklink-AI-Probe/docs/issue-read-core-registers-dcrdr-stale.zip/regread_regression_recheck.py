"""Firmware recheck: read_all_core_registers x10 after a firmware update.

Per docs/issue-read-core-registers-dcrdr-stale.md §7 regression criteria:
  - PC  in 0x08000000..0x080FFFFF (STM32F405 1MB flash)
  - SP  in SRAM/CCM
  - control small byte
  - no 0xDEADBEEF sentinel
  - DHCSR.S_HALT must stay 1 across the 23-register read (probe must NOT
    perturb halt mid-read); S_RESET_ST must not get set spuriously.

A read is GOOD only if every check passes. Any BAD == the probe-perturbation
bug still present.
"""
import sys, time
from collections import Counter
from mklink.bridge import MKLinkSerialBridge
from mklink.debug_control import halt_cpu, resume_cpu, read_all_core_registers, _read_u32

port = sys.argv[1] if len(sys.argv) > 1 else "COM5"
DHCSR = 0xE000EDF0
S_HALT = 1 << 17
S_RESET_ST = 1 << 25
SENTINELS = {0xDEADBEEF, 0x00000000}  # 0 guarded per-reg below

b = MKLinkSerialBridge(port)
if not b.connect():
    raise SystemExit(f"connect({port}) failed")

FLASH_LO, FLASH_HI = 0x08000000, 0x08100000
SRAM_LO, SRAM_HI = 0x20000000, 0x20020000
CCM_LO, CCM_HI = 0x10000000, 0x10010000


def flash_ok(pc):
    return FLASH_LO <= (pc & 0xFFFFFFFE) < FLASH_HI


def stack_ok(sp):
    return (SRAM_LO <= sp < SRAM_HI) or (CCM_LO <= sp < CCM_HI)


n_ok = n_bad = 0
print(f"=== read_all_core_registers x10 on {port} ===")
for i in range(10):
    resume_cpu(b); halt_cpu(b)
    d_pre = _read_u32(b, DHCSR)
    t0 = time.monotonic()
    regs = read_all_core_registers(b)
    dt = (time.monotonic() - t0) * 1000.0
    d_post = _read_u32(b, DHCSR)

    pc, sp, ctrl = regs["pc"], regs["sp"], regs["control"]

    # sentinel scan over the "should-be-unique" integer regs (exclude mask bytes)
    scan = {k: v for k, v in regs.items()
            if k not in ("control", "primask", "basepri", "faultmask")}
    sent_hits = [k for k, v in scan.items() if v == 0xDEADBEEF]

    # stale-flat scan: any value repeated >=5 times among r0-r12/msp/psp/xpsr/lr/pc
    # (a fresh halted state almost never has 5+ identical GP registers)
    repeats = Counter(scan.values())
    flat_val = [hex(v) for v, c in repeats.items() if c >= 5]

    pc_ok = flash_ok(pc)
    sp_ok = stack_ok(sp)
    ctrl_ok = ctrl in (0, 1, 2, 3)
    halt_kept = bool(d_pre & S_HALT) and bool(d_post & S_HALT)
    reset_st = bool(d_post & S_RESET_ST)

    reasons = []
    if not pc_ok:          reasons.append(f"PC={pc:#010x}")
    if not sp_ok:          reasons.append(f"SP={sp:#010x}")
    if not ctrl_ok:        reasons.append(f"CONTROL={ctrl}")
    if sent_hits:          reasons.append(f"sentinel@{sent_hits}")
    if flat_val:           reasons.append(f"stale-flat{flat_val}")
    if not halt_kept:      reasons.append(f"halt-lost(dhcsr {d_pre:#010x}->{d_post:#010x})")
    if reset_st:           reasons.append("S_RESET_ST=1")

    ok = not reasons
    n_ok += ok; n_bad += (not ok)
    flag = "GOOD" if ok else "BAD "
    rs = "" if ok else "  <- " + ", ".join(reasons)
    print(f"[{i}] {flag} dt={dt:5.1f}ms pc={pc:#010x} sp={sp:#010x} ctrl={ctrl} "
          f"S_HALT {bool(d_pre&S_HALT)}->{bool(d_post&S_HALT)}{rs}")

print(f"\nRESULT: GOOD={n_ok}/10  BAD={n_bad}/10")
resume_cpu(b); b.close()
