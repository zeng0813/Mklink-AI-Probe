"""Definitive: WHAT resets the core during a long halt?

Clear RCC_CSR reset flags, halt, then poll until a reset/drop is detected, then
immediately read RCC_CSR to see which reset source fired.

STM32F405 RCC_CSR @ 0x40023810 flags:
  LPWRRSTF=1<<31  WWDGRSTF=1<<30  IWDGRSTF=1<<29  SFTRSTF=1<<28
  PORRSTF=1<<27   PINRSTF=1<<26   BORRSTF=1<<25   RMVF(clear)=1<<23
"""
import sys, time
from mklink.bridge import MKLinkSerialBridge
from mklink.debug_control import halt_cpu, resume_cpu, _write_u32, _read_u32

port = sys.argv[1] if len(sys.argv) > 1 else "COM5"
DHCSR = 0xE000EDF0
RCC_CSR = 0x40023810
RMVF = 1 << 23
S_HALT = 1 << 17
S_RESET_ST = 1 << 25

FLAGS = {
    "LPWRRSTF": 1 << 31, "WWDGRSTF": 1 << 30, "IWDGRSTF": 1 << 29,
    "SFTRSTF": 1 << 28, "PORRSTF": 1 << 27, "PINRSTF": 1 << 26, "BORRSTF": 1 << 25,
}


def decode_csr(v):
    return [k for k, m in FLAGS.items() if v & m] or ["(none)"]


b = MKLinkSerialBridge(port)
if not b.connect():
    raise SystemExit(f"connect({port}) failed")

for attempt in range(4):
    resume_cpu(b); halt_cpu(b)
    _write_u32(b, RCC_CSR, RMVF)              # clear prior reset flags
    cleared = _read_u32(b, RCC_CSR) & ~RMVF
    print(f"\n[attempt {attempt}] RCC_CSR after clear: {cleared:#010x} -> {decode_csr(cleared)}")
    t0 = time.monotonic()
    detected = None
    while time.monotonic() - t0 < 20.0:
        time.sleep(0.3)
        d = _read_u32(b, DHCSR)
        if (d & S_RESET_ST) or not (d & S_HALT):
            detected = d
            break
    if detected is None:
        print("  no reset/drop in 20s")
        continue
    elapsed = time.monotonic() - t0
    try:
        csr = _read_u32(b, RCC_CSR) & ~RMVF
        flags = decode_csr(csr)
    except Exception as e:
        csr, flags = 0, [f"read-failed:{e}"]
    kind = "RESET" if (detected & S_RESET_ST) else "halt-drop(no-reset-bit)"
    print(f"  {kind} after {elapsed:.1f}s  DHCSR={detected:#010x}")
    print(f"  RCC_CSR = {csr:#010x} -> {flags}")

resume_cpu(b); b.close()
