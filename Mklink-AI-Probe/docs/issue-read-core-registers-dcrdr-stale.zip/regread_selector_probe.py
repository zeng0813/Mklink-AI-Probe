"""Pin down where the r6-r11 0xDEADBEEF comes from, while core is confirmed halted.

Each round re-halts and only counts if S_HALT stays 1 the whole time. Then:
  - direct DCRDR write/read (path intact?)
  - DCRSR sel=1  -> expect fresh r1
  - DCRSR sel=6  -> expect r6 (observed 0xDEADBEEF)
  - DCRSR sel=11 -> expect r11 (observed 0xDEADBEEF)
  - direct DCRDR write/read again
"""
import sys, time
from mklink.bridge import MKLinkSerialBridge
from mklink.debug_control import halt_cpu, resume_cpu, _read_u32, _write_u32, _wait_regrdy

port = sys.argv[1] if len(sys.argv) > 1 else "COM5"
DHCSR = 0xE000EDF0
DCRSR = 0xE000EDF4
DCRDR = 0xE000EDF8
S_HALT = 1 << 17

b = MKLinkSerialBridge(port)
if not b.connect():
    raise SystemExit("connect failed")


def rd(a):
    return _read_u32(b, a)


def wr(a, v):
    _write_u32(b, a, v)


for rnd in range(8):
    resume_cpu(b); halt_cpu(b)
    d0 = rd(DHCSR)
    if not (d0 & S_HALT):
        print(f"rnd{rnd}: not halted, skip"); continue
    wr(DCRDR, 0xAABBCCDD); v_dir1 = rd(DCRDR)
    wr(DCRSR, 1); _wait_regrdy(b); v_r1 = rd(DCRDR)
    wr(DCRSR, 6); _wait_regrdy(b); v_r6 = rd(DCRDR)
    wr(DCRSR, 11); _wait_regrdy(b); v_r11 = rd(DCRDR)
    wr(DCRDR, 0x55AA55AA); v_dir2 = rd(DCRDR)
    d1 = rd(DHCSR)
    kept = bool(d0 & S_HALT) and bool(d1 & S_HALT)
    tag = "HALT-KEPT" if kept else "HALT-LOST "
    print(f"rnd{rnd} {tag}  d0={d0:#010x}->d1={d1:#010x}")
    print(f"   DCRDR direct: 0xAABBCCDD->{v_dir1:#010x}   0x55AA55AA->{v_dir2:#010x}")
    print(f"   r1(sel1)={v_r1:#010x}   r6(sel6)={v_r6:#010x}   r11(sel11)={v_r11:#010x}")

resume_cpu(b); b.close()
