"""Disambiguate: is the r6-r11 0xDEADBEEF (a) probe halts-loss (old bug), or
(b) firmware AP returning a sentinel for specific DCRSR selectors even while
the core is demonstrably halted (firmware-update-induced)?

(1) measure single PPB read_ram latency  (2) scan r0-r12 under confirmed,
continuous S_HALT.  If sentinel persists while S_HALT stays 1 across the whole
scan, it's (b) — independent of the halt-perturbation bug.
"""
import sys, time
from mklink.bridge import MKLinkSerialBridge
from mklink.debug_control import halt_cpu, resume_cpu, read_core_register, _read_u32

port = sys.argv[1] if len(sys.argv) > 1 else "COM5"
DHCSR = 0xE000EDF0
S_HALT = 1 << 17
S_RESET_ST = 1 << 25

b = MKLinkSerialBridge(port)
if not b.connect():
    raise SystemExit("connect failed")

resume_cpu(b); halt_cpu(b)

# (1) PPB read latency
ts = []
for _ in range(10):
    t0 = time.monotonic(); _read_u32(b, DHCSR); ts.append((time.monotonic() - t0) * 1000)
print(f"PPB read_ram(DHCSR) latency ms: min={min(ts):.1f} max={max(ts):.1f} avg={sum(ts)/len(ts):.1f}")

# (2) per-selector scan under confirmed-halt
print("selector scan r0-r12 (each round re-halts; S_HALT checked pre/post):")
for rnd in range(6):
    d0 = _read_u32(b, DHCSR)
    if not (d0 & S_HALT):
        resume_cpu(b); halt_cpu(b); d0 = _read_u32(b, DHCSR)
    vals = {}
    for sel in range(13):
        try:
            vals[sel] = read_core_register(b, sel)
        except Exception as e:
            vals[sel] = f"ERR:{type(e).__name__}"
    d1 = _read_u32(b, DHCSR)
    kept = bool(d0 & S_HALT) and bool(d1 & S_HALT)
    sent = [s for s in range(13) if vals[s] == 0xDEADBEEF]
    fresh = {s: f"{vals[s]:#010x}" for s in range(13) if vals[s] != 0xDEADBEEF and not str(vals[s]).startswith("ERR")}
    errs = [s for s in range(13) if str(vals[s]).startswith("ERR")]
    tag = "HALT-KEPT" if kept else "HALT-LOST "
    print(f" rnd{rnd} {tag} d0={d0:#010x}->d1={d1:#010x} sentinels@{sent} errs@{errs}")
    print(f"        fresh={fresh}")

resume_cpu(b); b.close()
