"""Decisive isolation: does freezing IWDG/WWDG eliminate the idle halt-loss?

Pure idle: halt, ONE DHCSR read to clear S_RESET_ST, then sleep (zero traffic),
then ONE DHCSR read. No resume cycling, no register reads during the wait.
Compare unfrozen vs frozen.
"""
import sys, time
from mklink.bridge import MKLinkSerialBridge
from mklink.debug_control import halt_cpu, resume_cpu, _write_u32, _read_u32

port = sys.argv[1] if len(sys.argv) > 1 else "COM5"
DHCSR = 0xE000EDF0
DBGMCU_CR = 0xE0042004
DBG_IWDG_STOP = 1 << 8
DBG_WWDG_STOP = 1 << 9
S_HALT = 1 << 17
S_RESET_ST = 1 << 25


def idle_test(b, secs, trials, frozen):
    drops = resets = 0
    for _ in range(trials):
        resume_cpu(b); halt_cpu(b)
        if frozen:
            cr = _read_u32(b, DBGMCU_CR)
            _write_u32(b, DBGMCU_CR, cr | DBG_IWDG_STOP | DBG_WWDG_STOP)
        _read_u32(b, DHCSR)          # clear S_RESET_ST, confirm halted
        time.sleep(secs)             # ZERO traffic
        d = _read_u32(b, DHCSR)
        if not (d & S_HALT):
            drops += 1
        if d & S_RESET_ST:
            resets += 1
    return drops, resets


b = MKLinkSerialBridge(port)
if not b.connect():
    raise SystemExit(f"connect({port}) failed")

resume_cpu(b); halt_cpu(b)
print(f"DBGMCU_CR now = {_read_u32(b, DBGMCU_CR):#010x}")

for frozen in (False, True):
    label = "FROZEN (IWDG+WWDG)" if frozen else "UNFROZEN"
    print(f"\n=== {label} ===")
    for secs in (2.0, 4.0, 8.0):
        d, r = idle_test(b, secs, 6, frozen)
        print(f"  idle {secs:>3.0f}s x6: drops={d}/6  resets={r}/6")

resume_cpu(b); b.close()
